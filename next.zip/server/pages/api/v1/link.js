"use strict";
(() => {
var exports = {};
exports.id = 478;
exports.ids = [478];
exports.modules = {

/***/ 741:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ v1_link)
});

// EXTERNAL MODULE: ./config/env.ts + 1 modules
var env = __webpack_require__(319);
// EXTERNAL MODULE: ./src/utils/uid-generator.ts
var uid_generator = __webpack_require__(126);
;// CONCATENATED MODULE: ./src/utils/object-to-query-string.ts
function objectToQueryString(params) {
    if (!params) return;
    return Object.keys(params).map((key)=>key + "=" + params[key]
    ).join("&");
}

;// CONCATENATED MODULE: ./src/lib/airtable.ts


function fetchLinks(reqconfig) {
    return {
        getLinks: async function(params) {
            const response = await fetch(`${reqconfig.baseURL}/${env/* config.AT_SHEET */.v.AT_SHEET}?${objectToQueryString(params)}`, {
                headers: new Headers(reqconfig.headers)
            });
            const data = await response.json();
            return {
                data
            };
        }
    };
}
function createLink(reqconfig) {
    return {
        addLink: async function(link) {
            const params = {
                records: [
                    {
                        fields: link
                    }
                ]
            };
            const response = await fetch(`${reqconfig.baseURL}/${env/* config.AT_SHEET */.v.AT_SHEET}`, {
                headers: new Headers(reqconfig.headers),
                method: "post",
                body: JSON.stringify(params)
            });
            const data = await response.json();
            return {
                data
            };
        }
    };
}
function airtable() {
    const config = {
        tableid: env/* config.AT_TABLEID */.v.AT_TABLEID,
        apiurl: "https://api.airtable.com/v0"
    };
    const reqconfig = {
        headers: {
            Authorization: `Bearer ${env/* config.AT_APIKEY */.v.AT_APIKEY}`,
            "Content-Type": "application/json"
        },
        baseURL: `${config.apiurl}/${config.tableid}`
    };
    return {
        ...config,
        ...fetchLinks(reqconfig),
        ...createLink(reqconfig)
    };
}
/* harmony default export */ const lib_airtable = (airtable);

// EXTERNAL MODULE: ./src/lib/router.ts
var router = __webpack_require__(148);
;// CONCATENATED MODULE: ./src/pages/api/v1/link.ts




const api = lib_airtable();
const link_router = (0,router/* default */.Z)();
const linkDomain = env/* config.LINK_DOMAIN */.v.LINK_DOMAIN;
link_router.get(async function(req, res) {
    const { alias  } = req.query;
    try {
        const { data  } = await api.getLinks({
            filterByFormula: `FIND("${alias}", {alias})`
        });
        res.json(data.records);
    } catch (err) {
        res.status(400).json({
            message: "Unexpected Error"
        });
    }
});
link_router.post(async function(req, res) {
    const { link , alias  } = req.body;
    if (!link) {
        return res.status(400).json({
            error: {
                status: "Bad Request",
                message: "Missing link param"
            }
        });
    }
    if (alias !== "") {
        try {
            const { data  } = await api.getLinks({
                filterByFormula: `FIND("${alias}", {alias})`
            });
            if (data.records.length > 0) throw {
                error: {
                    status: "Bad Request",
                    message: `Alias ${alias} already exists`
                }
            };
        } catch (err) {
            return res.status(400).json(err);
        }
    }
    try {
        const { data  } = await api.addLink({
            uid: (0,uid_generator/* uid */.h)(),
            link,
            alias
        });
        const { uid: linkUid  } = data.records[0].fields;
        res.status(201).json({
            data: {
                link: `${linkDomain}/${alias.trim() ? alias : linkUid}`
            }
        });
    } catch (err) {
        return res.status(400).json({
            message: "Unexpected Error"
        });
    }
});
/* harmony default export */ const v1_link = (link_router);


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [739], () => (__webpack_exec__(741)));
module.exports = __webpack_exports__;

})();