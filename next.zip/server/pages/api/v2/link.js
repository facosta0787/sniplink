"use strict";
(() => {
var exports = {};
exports.id = 992;
exports.ids = [992];
exports.modules = {

/***/ 803:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ v2_link)
});

// EXTERNAL MODULE: ./config/env.ts + 1 modules
var env = __webpack_require__(319);
// EXTERNAL MODULE: ./src/utils/uid-generator.ts
var uid_generator = __webpack_require__(126);
// EXTERNAL MODULE: ./src/lib/router.ts
var router = __webpack_require__(148);
;// CONCATENATED MODULE: external "@prisma/client"
const client_namespaceObject = require("@prisma/client");
;// CONCATENATED MODULE: ./src/lib/db.ts


const prisma = new client_namespaceObject.PrismaClient({
    datasources: {
        db: {
            url: env/* config.DB_CONNECTION_STRING */.v.DB_CONNECTION_STRING
        }
    },
    log: env/* config.IS_DEV */.v.IS_DEV ? [
        "query"
    ] : []
});
function linkCreate() {
    return {
        create: async function(link) {
            const created = await prisma.link.create({
                data: {
                    hash: link.hash,
                    link: link.link,
                    alias: link.alias
                }
            });
            return created;
        }
    };
}
function linkFind() {
    return {
        find: async function(where) {
            const found = await prisma.link.findUnique({
                where
            });
            return found;
        }
    };
}
function db() {
    return {
        conn: prisma,
        link: {
            ...linkCreate(),
            ...linkFind()
        }
    };
}
/* harmony default export */ const lib_db = (db());

;// CONCATENATED MODULE: ./src/pages/api/v2/link.ts




const link_router = (0,router/* default */.Z)();
const linkDomain = env/* config.LINK_DOMAIN */.v.LINK_DOMAIN;
link_router.get(async function(req, res) {
    const { q  } = req.query;
    try {
        const link = await lib_db.conn.link.findFirstOrThrow({
            where: {
                OR: [
                    {
                        hash: {
                            equals: q
                        }
                    },
                    {
                        alias: {
                            equals: q
                        }
                    }
                ]
            }
        });
        return res.status(200).json({
            link
        });
    } catch (error) {
        return res.status(400).json({
            status: 400,
            code: error.code,
            name: error.name
        });
    }
});
link_router.post(async function(req, res) {
    const { link , alias  } = req.body;
    if (!link) {
        return res.status(400).json({
            error: {
                status: "Bad Request",
                message: "Missing link param"
            }
        });
    }
    if (alias && alias !== "") {
        try {
            const foundLink = await lib_db.link.find({
                alias
            });
            if (foundLink) {
                throw {
                    error: {
                        status: "Bad Request",
                        message: `Alias ${alias} already exists`
                    },
                    data: foundLink
                };
            }
        } catch (err) {
            console.error("api/v2/links:error ", err);
            res.status(400).json(err);
        }
    }
    const newLink = alias ? {
        hash: (0,uid_generator/* uid */.h)(),
        link,
        alias
    } : {
        hash: (0,uid_generator/* uid */.h)(),
        link
    };
    try {
        var ref;
        const created = await lib_db.link.create(newLink);
        return res.status(201).json({
            data: {
                link: `${linkDomain}/${((ref = created.alias) === null || ref === void 0 ? void 0 : ref.trim()) ? created.alias : created.hash}`
            }
        });
    } catch (err) {
        console.error("api/v2/links:error ", err);
        return res.status(400).json({
            message: "Unexpected Error"
        });
    }
});
/* harmony default export */ const v2_link = (link_router);


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [739], () => (__webpack_exec__(803)));
module.exports = __webpack_exports__;

})();