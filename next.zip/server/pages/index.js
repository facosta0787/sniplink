(() => {
var exports = {};
exports.id = 405;
exports.ids = [405];
exports.modules = {

/***/ 394:
/***/ ((module) => {

// Exports
module.exports = {
	"button": "Button_button__PjVhE"
};


/***/ }),

/***/ 680:
/***/ ((module) => {

// Exports
module.exports = {
	"container": "Home_container__He7vt",
	"icon": "Home_icon__WLG0C",
	"shortenForm": "Home_shortenForm__DS3OB",
	"formGroup": "Home_formGroup__pTrBF",
	"submitButton": "Home_submitButton__Sp1rp",
	"urlStringError": "Home_urlStringError__SlDAp",
	"urlStringErrorShow": "Home_urlStringErrorShow__wYBWE",
	"aliasCaption": "Home_aliasCaption__ZFZmk",
	"resultContainer": "Home_resultContainer__ygM6_"
};


/***/ }),

/***/ 782:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ pages)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
;// CONCATENATED MODULE: external "next/head"
const head_namespaceObject = require("next/head");
var head_default = /*#__PURE__*/__webpack_require__.n(head_namespaceObject);
;// CONCATENATED MODULE: external "validator/lib/isURL"
const isURL_namespaceObject = require("validator/lib/isURL");
var isURL_default = /*#__PURE__*/__webpack_require__.n(isURL_namespaceObject);
;// CONCATENATED MODULE: external "classnames"
const external_classnames_namespaceObject = require("classnames");
var external_classnames_default = /*#__PURE__*/__webpack_require__.n(external_classnames_namespaceObject);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(689);
// EXTERNAL MODULE: external "react-query"
var external_react_query_ = __webpack_require__(175);
// EXTERNAL MODULE: ./src/components/Button/Button.module.scss
var Button_module = __webpack_require__(394);
var Button_module_default = /*#__PURE__*/__webpack_require__.n(Button_module);
;// CONCATENATED MODULE: ./src/components/Button/Button.tsx



const Button = ({ children , onClick , className , ...restProps })=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("button", {
        className: external_classnames_default()((Button_module_default()).button, {
            [className]: Boolean(className)
        }),
        onClick: onClick,
        ...restProps,
        children: children
    });
};


;// CONCATENATED MODULE: ./src/components/Button/index.tsx


// EXTERNAL MODULE: ./src/shared/styles-pages/Home.module.scss
var Home_module = __webpack_require__(680);
var Home_module_default = /*#__PURE__*/__webpack_require__.n(Home_module);
;// CONCATENATED MODULE: ./src/pages/index.tsx








async function createLink({ shorten , alias  }) {
    const response = await fetch("/api/v2/link", {
        headers: new Headers({
            "Content-type": "application/json"
        }),
        method: "post",
        body: JSON.stringify({
            link: shorten,
            alias
        })
    });
    if (!response.ok) {
        const { error  } = await response.json();
        throw new Error(error.message);
    }
    return response.json();
}
const initialStateFormLink = {
    shorten: "",
    alias: ""
};
const Home = ()=>{
    const { 0: result , 1: setResult  } = (0,external_react_.useState)("");
    const { 0: error1 , 1: setError  } = (0,external_react_.useState)(null);
    const { 0: copied , 1: setCopied  } = (0,external_react_.useState)(false);
    const { 0: formLink , 1: setFormLink  } = (0,external_react_.useState)(initialStateFormLink);
    const linksMutation = (0,external_react_query_.useMutation)(createLink, {
        onSuccess: ({ data  })=>{
            setResult(data.link);
            setFormLink(initialStateFormLink);
        },
        onError: (error)=>{
            setError(`❌   ${error}`);
            setTimeout(()=>setError(null)
            , 3000);
        }
    });
    const handleSubmit = (event)=>{
        event.preventDefault();
        const { shorten , alias  } = formLink;
        if (!isURL_default()(shorten)) {
            setError("\u274C   Oops! that doesn't look a URL");
            setTimeout(()=>setError(null)
            , 3000);
            return;
        }
        linksMutation.mutate({
            shorten,
            alias
        });
    };
    const handleCopyClick = ()=>{
        navigator.clipboard.writeText(result);
        setCopied(true);
        setTimeout(()=>setCopied(false)
        , 1500);
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((head_default()), {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                        charSet: "UTF-8"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                        httpEquiv: "X-UA-Compatible",
                        content: "IE=edge"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                        name: "viewport",
                        content: "width=device-width, initial-scale=1.0, maximum-scale=1.0"
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (Home_module_default()).container,
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h1", {
                        children: [
                            "Sniplink ",
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: (Home_module_default()).icon,
                                children: "\u2702\uFE0F"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("form", {
                        className: (Home_module_default()).shortenForm,
                        onSubmit: handleSubmit,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                id: "shorten",
                                type: "text",
                                autoComplete: "off",
                                autoFocus: true,
                                placeholder: "Long URL",
                                value: formLink.shorten,
                                onChange: (event)=>setFormLink((prev)=>({
                                            ...prev,
                                            shorten: event.target.value
                                        })
                                    )
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: (Home_module_default()).formGroup,
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                        id: "alias",
                                        type: "text",
                                        autoComplete: "off",
                                        placeholder: "Alias",
                                        value: formLink.alias,
                                        onChange: (event)=>setFormLink((prev)=>({
                                                    ...prev,
                                                    alias: event.target.value
                                                })
                                            )
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(Button, {
                                        type: "submit",
                                        className: (Home_module_default()).submitButton,
                                        children: "Shorten"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: (Home_module_default()).aliasCaption,
                                children: "Alias must be hyphen separated. Example: this-is-my-alias"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                className: external_classnames_default()((Home_module_default()).urlStringError, {
                                    [(Home_module_default()).urlStringErrorShow]: Boolean(error1)
                                }),
                                children: error1
                            })
                        ]
                    }),
                    Boolean(result) && /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (Home_module_default()).resultContainer,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                href: result,
                                target: "_blank",
                                rel: "noreferrer",
                                className: (Home_module_default()).resultLink,
                                children: result
                            }),
                            copied ? /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                children: "copied! \uD83D\uDC4D\uD83C\uDFFC"
                            }) : /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                onClick: handleCopyClick,
                                children: "\uD83D\uDCD1"
                            })
                        ]
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const pages = (Home);


/***/ }),

/***/ 689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 175:
/***/ ((module) => {

"use strict";
module.exports = require("react-query");

/***/ }),

/***/ 997:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(782));
module.exports = __webpack_exports__;

})();