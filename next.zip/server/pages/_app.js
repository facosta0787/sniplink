"use strict";
(() => {
var exports = {};
exports.id = 888;
exports.ids = [888];
exports.modules = {

/***/ 499:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ _app)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./node_modules/next/app.js
var app = __webpack_require__(544);
// EXTERNAL MODULE: external "react-query"
var external_react_query_ = __webpack_require__(175);
;// CONCATENATED MODULE: ./package.json
const package_namespaceObject = JSON.parse('{"cj":{"H":"https://github.com/facosta0787/sniplink"}}');
;// CONCATENATED MODULE: ./config/env.ts

const config = {
    IS_DEV: "production" !== "production",
    LINK_DOMAIN: process.env.LINK_DOMAIN || "",
    AT_APIKEY: process.env.AT_APIKEY,
    AT_TABLEID: process.env.AT_TABLEID,
    AT_SHEET: process.env.AT_SHEET,
    DB_CONNECTION_STRING: process.env.DATABASE_URL,
    NEXT_PUBLIC_REPO_URL: package_namespaceObject.cj.H
};

;// CONCATENATED MODULE: ./src/components/Envlabel/Envlabel.tsx


const Envlabel = ({ host  })=>{
    const styles = {
        display: "inline-block",
        position: "fixed",
        left: "1rem",
        bottom: "1rem",
        backgroundColor: "black",
        color: "white",
        fontWeight: 600,
        padding: "0.25rem 0.5rem",
        borderRadius: "5px",
        fontSize: "0.75rem",
        textDecoration: "none"
    };
    const getLabelText = ()=>{
        if (host.includes("sniplink-pr")) {
            return host.split(".")[0].replace(/sniplink-/g, "").toUpperCase();
        }
        if (host.includes("stage")) return "stage";
        if (host.includes("localhost")) return "development";
        return "production";
    };
    if (getLabelText() === "production") return null;
    if (getLabelText().includes("PR-")) {
        return /*#__PURE__*/ jsx_runtime_.jsx("a", {
            style: styles,
            href: `${config.NEXT_PUBLIC_REPO_URL}/pull/${getLabelText().split("-")[1]}`,
            target: "_blank",
            rel: "noreferrer",
            children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                children: getLabelText()
            })
        });
    }
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        style: styles,
        children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
            children: getLabelText()
        })
    });
};

;// CONCATENATED MODULE: ./src/components/Envlabel/index.tsx


;// CONCATENATED MODULE: ./src/pages/_app.tsx





const queryClient = new external_react_query_.QueryClient();
function MyApp(props) {
    const { Component , pageProps , host  } = props;
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(external_react_query_.QueryClientProvider, {
        client: queryClient,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(Component, {
                ...pageProps
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(Envlabel, {
                host: host
            })
        ]
    });
}
MyApp.getInitialProps = async (appContext)=>{
    const { req  } = appContext.ctx;
    const appProps = await app["default"].getInitialProps(appContext);
    return {
        ...appProps,
        host: req === null || req === void 0 ? void 0 : req.headers.host
    };
};
/* harmony default export */ const _app = (MyApp);


/***/ }),

/***/ 232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 175:
/***/ ((module) => {

module.exports = require("react-query");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [544], () => (__webpack_exec__(499)));
module.exports = __webpack_exports__;

})();