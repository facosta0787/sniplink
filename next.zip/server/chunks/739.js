"use strict";
exports.id = 739;
exports.ids = [739];
exports.modules = {

/***/ 319:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "v": () => (/* binding */ config)
});

;// CONCATENATED MODULE: ./package.json
const package_namespaceObject = JSON.parse('{"cj":{"H":"https://github.com/facosta0787/sniplink"}}');
;// CONCATENATED MODULE: ./config/env.ts

const config = {
    IS_DEV: "production" !== "production",
    LINK_DOMAIN: process.env.LINK_DOMAIN || "",
    AT_APIKEY: process.env.AT_APIKEY,
    AT_TABLEID: process.env.AT_TABLEID,
    AT_SHEET: process.env.AT_SHEET,
    DB_CONNECTION_STRING: process.env.DATABASE_URL,
    NEXT_PUBLIC_REPO_URL: package_namespaceObject.cj.H
};


/***/ }),

/***/ 148:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ Router)
/* harmony export */ });
function Router() {
    const handle = {};
    async function router(req, res) {
        switch(req.method){
            case "GET":
                if (router.handle.get) {
                    await router.handle.get(req, res);
                    break;
                }
            case "POST":
                if (router.handle.post) {
                    await router.handle.post(req, res);
                    break;
                }
            case "DELETE":
                if (router.handle.delete) {
                    await router.handle.delete(req, res);
                    break;
                }
            case "PUT":
                if (router.handle.put) {
                    await router.handle.put(req, res);
                    break;
                }
            case "PATCH":
                if (router.handle.patch) {
                    await router.handle.patch(req, res);
                    break;
                }
            default:
                res.status(405).json({
                    status: "Method Not Allowed",
                    message: `Method ${req.method} not allowed`
                });
        }
    }
    router.handle = handle;
    router.get = function(cb) {
        router.handle.get = cb;
    };
    router.post = function(cb) {
        router.handle.post = cb;
    };
    router.delete = function(cb) {
        router.handle.delete = cb;
    };
    router.put = function(cb) {
        router.handle.put = cb;
    };
    router.patch = function(cb) {
        router.handle.patch = cb;
    };
    return router;
};


/***/ }),

/***/ 126:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "h": () => (/* binding */ uid)
/* harmony export */ });
function uid(strLength = 8) {
    const numbers = "1234567890";
    const letters = "abcdefghijklmnopqrstuvwxyz";
    const characters = letters + numbers + letters.toUpperCase();
    return Array(strLength).fill(null).map(()=>{
        return characters.charAt(Math.floor(Math.random() * characters.length));
    }).join("");
}


/***/ })

};
;